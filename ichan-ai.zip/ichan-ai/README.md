# Ichan Ai

Aplikasi web open-source: asisten AI + browser sederhana dalam satu halaman.
Statis (HTML/CSS/JS) + satu Netlify Function kecil untuk memanggil Claude API
tanpa membocorkan API key ke browser.

## Struktur

```
ichan-ai/
├── index.html              halaman utama (UI asisten + browser)
├── style.css                tampilan
├── app.js                   logika frontend
├── netlify.toml              konfigurasi Netlify
├── netlify/functions/chat.js fungsi server yang memanggil Anthropic API
└── LICENSE                   MIT
```

## Menjalankan lokal

Butuh [Netlify CLI](https://docs.netlify.com/cli/get-started/):

```bash
npm install -g netlify-cli
netlify dev
```

Ini menjalankan situs statis sekaligus fungsi `/netlify/functions/chat.js` di
`http://localhost:8888`.

## Deploy ke Netlify

1. Push folder ini ke repo GitHub/GitLab kamu.
2. Di [app.netlify.com](https://app.netlify.com), klik **Add new site → Import an existing project**, pilih repo tersebut.
3. Build settings sudah diatur lewat `netlify.toml` — tidak perlu build command, publish directory `.`.
4. Setelah situs dibuat, buka **Site settings → Environment variables** dan tambahkan:
   - `ANTHROPIC_API_KEY` = API key Anthropic kamu (dapatkan di [console.anthropic.com](https://console.anthropic.com))
5. Redeploy situs supaya environment variable terbaca.

Tanpa langkah 4–5, tab **Browser** tetap berfungsi, tapi tab **Asisten** akan
menampilkan pesan bahwa server AI belum terhubung.

## Cara kerja fitur Browser

Tab Browser memuat situs lain lewat `<iframe>`. Beberapa situs besar (Google,
Facebook, Instagram, dll.) mengirim header `X-Frame-Options` yang memblokir
penyematan — situs itu akan tampil kosong di sini, ini batasan dari situs
tujuan, bukan bug aplikasi. Situs seperti Wikipedia dan DuckDuckGo biasanya
tampil normal.

## Keamanan

- API key Anthropic **hanya** hidup di environment variable server (Netlify
  Function), tidak pernah dikirim ke browser.
- `netlify/functions/chat.js` meneruskan riwayat chat ke Anthropic dan
  mengembalikan balasan teks saja.

## Lisensi

MIT — bebas dipakai, diubah, dan didistribusikan ulang. Lihat [LICENSE](LICENSE).
