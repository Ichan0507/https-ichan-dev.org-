// Netlify Function: proxies chat messages to the Anthropic API.
// Keeps the API key on the server so it's never exposed to the browser.
//
// Requires an environment variable set in the Netlify dashboard:
//   ANTHROPIC_API_KEY = sk-ant-...
//
// Docs on getting a key: https://docs.claude.com/en/api/overview

const ANTHROPIC_URL = 'https://api.anthropic.com/v1/messages';
const MODEL = 'claude-sonnet-4-6';

exports.handler = async function (event) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method not allowed' };
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return {
      statusCode: 500,
      body: JSON.stringify({
        error: 'ANTHROPIC_API_KEY is not set. Add it in Netlify: Site settings > Environment variables.'
      })
    };
  }

  let payload;
  try {
    payload = JSON.parse(event.body || '{}');
  } catch (e) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid JSON body' }) };
  }

  const messages = Array.isArray(payload.messages) ? payload.messages : [];
  if (messages.length === 0) {
    return { statusCode: 400, body: JSON.stringify({ error: 'messages is required' }) };
  }

  try {
    const response = await fetch(ANTHROPIC_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: 1024,
        messages: messages,
        system: 'Kamu adalah Ichan Ai, asisten yang ramah dan membantu. Jawab dalam Bahasa Indonesia kecuali diminta lain.'
      })
    });

    const data = await response.json();

    if (!response.ok) {
      return {
        statusCode: response.status,
        body: JSON.stringify({ error: data.error && data.error.message ? data.error.message : 'Anthropic API error' })
      };
    }

    const textBlock = (data.content || []).find(function (b) { return b.type === 'text'; });
    const reply = textBlock ? textBlock.text : '';

    return {
      statusCode: 200,
      body: JSON.stringify({ reply: reply })
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Failed to reach Anthropic API' })
    };
  }
};
