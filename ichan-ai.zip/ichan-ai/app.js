(function () {
  // ---------- Tabs ----------
  var tabBtns = document.querySelectorAll('.tab-btn');
  var panels = { ai: document.getElementById('panel-ai'), browser: document.getElementById('panel-browser') };
  tabBtns.forEach(function (btn) {
    btn.addEventListener('click', function () {
      tabBtns.forEach(function (b) { b.classList.remove('active'); });
      btn.classList.add('active');
      Object.keys(panels).forEach(function (k) { panels[k].classList.remove('active'); });
      panels[btn.dataset.tab].classList.add('active');
    });
  });

  // ---------- AI chat ----------
  // This calls the Netlify Function at /.netlify/functions/chat, which
  // holds the real Anthropic API key server-side (see netlify/functions/chat.js).
  var CHAT_ENDPOINT = '/.netlify/functions/chat';

  var chatLog = document.getElementById('chatLog');
  var chatEmpty = document.getElementById('chatEmpty');
  var chatForm = document.getElementById('chatForm');
  var chatInput = document.getElementById('chatInput');
  var sendBtn = document.getElementById('sendBtn');
  var history = []; // {role, content}

  function autoGrow() {
    chatInput.style.height = 'auto';
    chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + 'px';
  }
  chatInput.addEventListener('input', autoGrow);

  function addMessage(role, text) {
    if (chatEmpty) { chatEmpty.remove(); chatEmpty = null; }
    var div = document.createElement('div');
    div.className = 'msg ' + (role === 'user' ? 'user' : 'ai');
    div.textContent = text;
    chatLog.appendChild(div);
    chatLog.scrollTop = chatLog.scrollHeight;
    return div;
  }

  function loadPrompt(text) {
    chatInput.value = text;
    autoGrow();
    chatForm.requestSubmit();
  }
  document.querySelectorAll('.chip').forEach(function (c) {
    c.addEventListener('click', function () { loadPrompt(c.dataset.prompt); });
  });

  chatForm.addEventListener('submit', function (e) {
    e.preventDefault();
    var text = chatInput.value.trim();
    if (!text) return;
    addMessage('user', text);
    history.push({ role: 'user', content: text });
    chatInput.value = '';
    autoGrow();
    sendBtn.disabled = true;

    var bubble = addMessage('ai', 'Mengetik...');
    bubble.classList.add('thinking');

    fetch(CHAT_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages: history })
    })
      .then(function (res) {
        if (!res.ok) throw new Error('Bad response: ' + res.status);
        return res.json();
      })
      .then(function (data) {
        bubble.classList.remove('thinking');
        var reply = data.reply || 'Maaf, tidak ada jawaban.';
        bubble.textContent = reply;
        history.push({ role: 'assistant', content: reply });
      })
      .catch(function () {
        bubble.classList.remove('thinking');
        bubble.textContent = 'Tidak bisa menghubungi server AI. Pastikan fungsi Netlify dan API key sudah dikonfigurasi (lihat README).';
      })
      .finally(function () {
        sendBtn.disabled = false;
        chatLog.scrollTop = chatLog.scrollHeight;
      });
  });

  chatInput.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      chatForm.requestSubmit();
    }
  });

  // ---------- Browser ----------
  var siteFrame = document.getElementById('siteFrame');
  var urlForm = document.getElementById('urlForm');
  var urlInput = document.getElementById('urlInput');
  var frameHint = document.getElementById('frameHint');
  var backBtn = document.getElementById('backBtn');
  var reloadBtn = document.getElementById('reloadBtn');
  var navStack = [];

  function normalizeUrl(raw) {
    raw = raw.trim();
    if (!raw) return null;
    if (!/^https?:\/\//i.test(raw)) {
      if (/^[\w.-]+\.[a-z]{2,}(\/.*)?$/i.test(raw)) {
        raw = 'https://' + raw;
      } else {
        raw = 'https://duckduckgo.com/?q=' + encodeURIComponent(raw);
      }
    }
    return raw;
  }

  function openUrl(raw, pushHistory) {
    var url = normalizeUrl(raw);
    if (!url) return;
    if (frameHint) frameHint.style.display = 'none';
    siteFrame.src = url;
    urlInput.value = url;
    if (pushHistory !== false) navStack.push(url);
  }

  urlForm.addEventListener('submit', function (e) {
    e.preventDefault();
    openUrl(urlInput.value);
  });

  document.querySelectorAll('.shortcut').forEach(function (s) {
    s.addEventListener('click', function () { openUrl(s.dataset.url); });
  });

  backBtn.addEventListener('click', function () {
    if (navStack.length > 1) {
      navStack.pop();
      var prev = navStack[navStack.length - 1];
      openUrl(prev, false);
    }
  });
  reloadBtn.addEventListener('click', function () {
    if (siteFrame.src) siteFrame.src = siteFrame.src;
  });
})();
